export const P5_VERSION = '0.4.23';
export const PREVIEW_WIDTH = 150;
export const HEIGHT = 300;
export const MAX_RUN_TIME = 1000;
