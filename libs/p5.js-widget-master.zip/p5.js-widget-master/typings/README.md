This directory contains TypeScript type definitions for third-party
libraries.

Most of the definitions are taken from
[DefinitelyTyped](https://github.com/DefinitelyTyped/DefinitelyTyped).
