// This is an example of an external file that can be loaded
// into the widget via the `src` attribute.

function setup() {
  createCanvas(300, 100);
  background(255, 0, 200);
}
